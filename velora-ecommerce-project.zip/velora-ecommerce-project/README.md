# VELORA — E-commerce Storefront

A responsive minimalist lifestyle e-commerce storefront built with HTML, CSS, and vanilla JavaScript.

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. No build tools or installation are required.

## Features
- Responsive homepage and product catalog
- Eight sample products across three categories
- Category filtering, live search, and sorting
- Shopping bag with quantity controls, removal, and subtotal
- Wishlist/favorites
- Cart and wishlist saved in localStorage
- Demo checkout form with validation and confirmation
- Newsletter demo interaction
- Toast notifications, mobile navigation, and empty states
- Lazy-loaded product images and reduced-motion support

## Project files
- `index.html` — page structure
- `styles.css` — responsive visual styling
- `app.js` — product data and storefront interactions
- `design-exports/` — simple SVG reference files

## Note
This is a front-end student project. Checkout is simulated; it does not process real payments or create real orders.
