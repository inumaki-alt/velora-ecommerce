const products = [
 {id:1,name:"Sculpted Ceramic Vase",category:"Home",price:1250,desc:"Hand-finished stoneware",image:"https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=700&q=80"},
 {id:2,name:"Everyday Canvas Tote",category:"Accessories",price:890,desc:"An effortless daily carry",image:"https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=700&q=80"},
 {id:3,name:"Soft Form Throw",category:"Home",price:1850,desc:"Woven cotton blend",image:"https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=700&q=80"},
 {id:4,name:"Essential Glass Set",category:"Lifestyle",price:760,desc:"Set of two clear glasses",image:"https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=700&q=80"},
 {id:5,name:"Linen Daily Pouch",category:"Accessories",price:650,desc:"A place for little things",image:"https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=700&q=80"},
 {id:6,name:"Quiet Morning Candle",category:"Lifestyle",price:980,desc:"Warm cedar and soft musk",image:"https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=700&q=80"},
 {id:7,name:"Minimal Table Tray",category:"Home",price:1450,desc:"A considered finishing touch",image:"https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=700&q=80"},
 {id:8,name:"Weekend Bottle",category:"Lifestyle",price:1100,desc:"Reusable stainless steel",image:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=700&q=80"}
];
const peso = n => "₱" + n.toLocaleString("en-PH");
let cart = JSON.parse(localStorage.getItem("velora-cart") || "[]");
let favorites = JSON.parse(localStorage.getItem("velora-favorites") || "[]");
let category = "All";
const grid = document.querySelector("#product-grid");
const toastEl = document.querySelector("#toast");
function toast(message){toastEl.textContent=message;toastEl.classList.add("show");setTimeout(()=>toastEl.classList.remove("show"),2200)}
function renderProducts(){
 let list=products.filter(p=>(category==="All"||p.category===category)&&p.name.toLowerCase().includes(document.querySelector("#search-input").value.toLowerCase()));
 const sort=document.querySelector("#sort-select").value;
 if(sort==="low")list.sort((a,b)=>a.price-b.price);if(sort==="high")list.sort((a,b)=>b.price-a.price);if(sort==="az")list.sort((a,b)=>a.name.localeCompare(b.name));
 grid.innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><button class="heart ${favorites.includes(p.id)?"active":""}" data-fav="${p.id}" aria-label="Add ${p.name} to wishlist">${favorites.includes(p.id)?"♥":"♡"}</button></div><div class="product-info"><div><h3>${p.name}</h3><p>${p.desc}</p></div><span class="price">${peso(p.price)}</span></div><button class="add-button" data-add="${p.id}">ADD TO BAG +</button></article>`).join(""):'<p class="empty">No pieces found. Try another search.</p>';
}
function saveCart(){localStorage.setItem("velora-cart",JSON.stringify(cart));renderCart()}
function renderCart(){
 const count=cart.reduce((s,i)=>s+i.qty,0),total=cart.reduce((s,i)=>s+i.price*i.qty,0);
 document.querySelector("#cart-count").textContent=count;document.querySelector("#drawer-count").textContent=`(${count})`;document.querySelector("#cart-subtotal").textContent=peso(total);document.querySelector("#checkout-total").textContent=peso(total);
 document.querySelector("#cart-items").innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><img src="${i.image}" alt=""><div><h3>${i.name}</h3><p>${peso(i.price)}</p><div class="quantity"><button data-qty="${i.id}" data-change="-1">−</button>${i.qty}<button data-qty="${i.id}" data-change="1">+</button></div></div><button class="remove" data-remove="${i.id}" aria-label="Remove item">×</button></div>`).join(""):'<div class="empty">Your bag is waiting for something lovely.</div>';
}
function openCart(){document.querySelector("#cart-drawer").classList.add("open");document.querySelector("#overlay").classList.add("show")}
function closeCart(){document.querySelector("#cart-drawer").classList.remove("open");document.querySelector("#overlay").classList.remove("show")}
document.querySelector("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;category=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
document.querySelector("#search-input").addEventListener("input",renderProducts);document.querySelector("#sort-select").addEventListener("change",renderProducts);
grid.addEventListener("click",e=>{const add=e.target.closest("[data-add]");const fav=e.target.closest("[data-fav]");if(add){const p=products.find(x=>x.id===Number(add.dataset.add));const found=cart.find(x=>x.id===p.id);found?found.qty++:cart.push({...p,qty:1});saveCart();toast("Added to your bag")};if(fav){const id=Number(fav.dataset.fav);favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem("velora-favorites",JSON.stringify(favorites));renderProducts()}});
document.querySelector("#cart-items").addEventListener("click",e=>{const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");if(q){const item=cart.find(x=>x.id===Number(q.dataset.qty));item.qty+=Number(q.dataset.change);if(item.qty<=0)cart=cart.filter(x=>x.id!==item.id);saveCart()}if(r){cart=cart.filter(x=>x.id!==Number(r.dataset.remove));saveCart()}});
document.querySelector("#cart-toggle").addEventListener("click",openCart);document.querySelector("#close-cart").addEventListener("click",closeCart);document.querySelector("#overlay").addEventListener("click",closeCart);
document.querySelector("#checkout-button").addEventListener("click",()=>{if(!cart.length){toast("Your bag is empty");return}closeCart();document.querySelector("#checkout-dialog").showModal()});
document.querySelector("#close-checkout").addEventListener("click",()=>document.querySelector("#checkout-dialog").close());
document.querySelector("#checkout-form").addEventListener("submit",e=>{e.preventDefault();const order={items:cart,total:cart.reduce((s,i)=>s+i.price*i.qty,0),date:new Date().toISOString()};sessionStorage.setItem("velora-last-order",JSON.stringify(order));cart=[];saveCart();e.target.reset();document.querySelector("#checkout-dialog").close();toast("Thank you! Your demo order is confirmed.")});
document.querySelector("#newsletter-form").addEventListener("submit",e=>{e.preventDefault();sessionStorage.setItem("velora-newsletter",document.querySelector("#newsletter-email").value);e.target.reset();toast("You're on the list. Thank you!")});
document.querySelector(".menu-toggle").addEventListener("click",()=>document.querySelector(".nav-links").classList.toggle("show"));
document.querySelector("#search-toggle").addEventListener("click",()=>{document.querySelector("#shop").scrollIntoView();document.querySelector("#search-input").focus()});
renderProducts();renderCart();
